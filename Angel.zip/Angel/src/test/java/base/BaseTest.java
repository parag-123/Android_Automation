package base;

import io.appium.java_client.android.AndroidDriver;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;


public class BaseTest {
	public static AndroidDriver driver;
	static DesiredCapabilities capabilities = new DesiredCapabilities();

	
	@BeforeClass
	public void setup() throws MalformedURLException, InterruptedException{
		
			
			//AppiumDriverLocalService service = AppiumDriverLocalService.buildDefaultService();
			//service.start();
			
			
			capabilities.setCapability("platformName", "Android");
		      //capabilities.setCapability("platformVersion", "5.0");
		      capabilities.setCapability("noreset", false);
		      capabilities.setCapability("deviceName", "Android");
		      //capabilities.setCapability("app", "D:\\Appium_jars\\Test_apk\\Jionet_1.6.10.apk");
		      capabilities.setCapability("appPackage", "com.msf.angelmobile");
		      capabilities.setCapability("appActivity", "com.msf.angelmobile.home.HomeScreen");
		      driver = getDriver();
		      Thread.sleep(20000); // delay of 20s
		      System.out.println("App Launched");
		      //System.out.println(driver);
		}
		      
		public static AndroidDriver getDriver() throws MalformedURLException{
			driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
			return driver;
			
		}
		
		
	
	      
	 @AfterClass
	 public void tearDown() { 
		 System.out.println(driver);
		  driver.quit();
		 System.out.println("in afterSuite");
	 }
}
	 
	 
	 

