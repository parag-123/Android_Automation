package test;

import java.net.MalformedURLException;

import io.appium.java_client.android.AndroidDriver;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseTest;

import pages.LoginPage;
import org.testng.Reporter;



public class Login_Test extends BaseTest {
	
	@Test (priority = 0)
	public void checkApp_title() throws InterruptedException, MalformedURLException{
		LoginPage loginPage = new LoginPage (driver);
		
		
		// Page instantiations
		
		loginPage.appTitle();
			
	}
	
	@Test (priority = 1)
	public void Verify_Login_Page_Exists() throws InterruptedException, MalformedURLException{
	
		
		// Page instantiations
		LoginPage loginPage = new LoginPage (driver);
		
		loginPage.validateLoginpage();
			
	}
	
	@Test (priority = 2)
	public void Check_Invalid_Login() throws InterruptedException, MalformedURLException{
		
		
		// Page instantiations
	LoginPage loginPage = new LoginPage (driver);
		
		loginPage.invalidLogin();
			
	}
	

}
