package pages;

import io.appium.java_client.android.AndroidDriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import base.BaseTest;


public class LoginPage extends BaseTest {
	// Driver declaration
	AndroidDriver driver;
	
	
	  //Constructor to pass driver 
    public LoginPage (AndroidDriver driver){
    	this.driver = driver;
    }
    

    // Method to validate title of the app
	 public void appTitle() {
		 
		 WebElement title = driver.findElement(By.id("com.msf.angelmobile:id/psts_tab_title"));
		 System.out.println("Title of the App: "+title.getText());
		 
	 }
	
	 // Method to validate all fields on login page are displayed
	 public void validateLoginpage(){
		 System.out.println("Verify Login Page");
		 
		 
		 driver.findElement(By.id("com.msf.angelmobile:id/market_open_acc")).click();
		 
		 boolean username = driver.findElement(By.id("com.msf.angelmobile:id/username")).isDisplayed();
		 boolean password = driver.findElement(By.id("com.msf.angelmobile:id/password")).isDisplayed();
		 
		 if (username == true && password == true) {
			 System.out.println("Sign in page displayed");
		 } else {
			 System.out.println("Fail");
		 }
	    	
		    }
	 
	 // Method to check invalid login and capture error message
	 	 public void invalidLogin(){
		 System.out.println("Validate Invalid Login");
		 
		 //driver.findElement(By.className("android.widget.ImageButton")).click();
		 //driver.findElement(By.id("in.upstox.pro:id/menu_log_in")).click();
		 
		 driver.findElement(By.id("com.msf.angelmobile:id/username")).sendKeys("8965456524");
		 driver.findElement(By.id("com.msf.angelmobile:id/password")).sendKeys("hjhjhjhhhhjh");
		 driver.findElement(By.id("com.msf.angelmobile:id/loginbtn")).click();
		 System.out.println(driver.findElement(By.id("com.msf.angelmobile:id/error_info")).getText());
		 
	    	
		    }
	 
	
	
	
	
	
	
}
